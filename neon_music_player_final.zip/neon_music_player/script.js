const audio = document.getElementById('audio');
const carousel = document.getElementById('carousel');
const mainTitle = document.getElementById('mainTitle');
const mainArtist = document.getElementById('mainArtist');
const miniTitle = document.getElementById('miniTitle');
const miniArtist = document.getElementById('miniArtist');
const miniCover = document.getElementById('miniCover');
const playBtn = document.getElementById('playBtn');
const seekBar = document.getElementById('seekBar');
const currentTimeEl = document.getElementById('currentTime');
const durationEl = document.getElementById('duration');
const volumeBar = document.getElementById('volumeBar');
const playlistPanel = document.getElementById('playlistPanel');
const playlistItems = document.getElementById('playlistItems');
const app = document.querySelector('.player-app');

// Customise each track's cover path, e.g. cover: 'images/my-cover.jpg'. Covers render through HTML <img> elements.
const tracks = [
  {
    title: 'Midnight Drive', artist: 'Neon Avenue',
    cover: 'https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=700&q=85',
    audio: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'
  },
  {
    title: 'Golden Hour', artist: 'Solara',
    cover: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=700&q=85',
    audio: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3'
  },
  {
    title: 'Afterglow', artist: 'The Coastline',
    cover: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=700&q=85',
    audio: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3'
  },
  {
    title: 'Blue Skies', artist: 'Mira Sol',
    cover: 'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=700&q=85',
    audio: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3'
  },
  {
    title: 'City Lights', artist: 'Northbound',
    cover: 'https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=700&q=85',
    audio: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3'
  }
];

let currentIndex = 0;
let isShuffle = false;
let repeatMode = 0; // 0 off, 1 repeat all, 2 repeat one
let toastTimer;

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function formatTime(seconds) {
  if (!Number.isFinite(seconds)) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60).toString().padStart(2, '0');
  return `${mins}:${secs}`;
}
function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2200);
}
function renderCarousel() {
  carousel.innerHTML = '';
  const positions = ['left-two', 'left-one', 'active', 'right-one', 'right-two'];
  for (let offset = -2; offset <= 2; offset++) {
    const index = (currentIndex + offset + tracks.length) % tracks.length;
    const track = tracks[index];
    const card = document.createElement('button');
    card.className = `album-card ${positions[offset + 2]}`;
    card.type = 'button';
    card.setAttribute('aria-label', `Play ${track.title} by ${track.artist}`);
    card.innerHTML = `<img src="${escapeHTML(track.cover)}" alt="${escapeHTML(track.title)} cover" loading="lazy">
      <span class="album-info"><strong>${escapeHTML(track.title)}</strong><span>${escapeHTML(track.artist)}</span></span>`;
    card.addEventListener('click', () => {
      if (index === currentIndex) togglePlay();
      else selectTrack(index, true);
    });
    carousel.appendChild(card);
  }
}
function renderPlaylist() {
  playlistItems.innerHTML = '';
  tracks.forEach((track, index) => {
    const button = document.createElement('button');
    button.className = `playlist-item ${index === currentIndex ? 'current' : ''}`;
    button.type = 'button';
    button.innerHTML = `<img src="${escapeHTML(track.cover)}" alt="">
      <span><strong>${escapeHTML(track.title)}</strong><small>${escapeHTML(track.artist)}</small></span>
      <small>${index === currentIndex ? '♫' : ''}</small>`;
    button.addEventListener('click', () => selectTrack(index, true));
    playlistItems.appendChild(button);
  });
}
function updateUI() {
  const track = tracks[currentIndex];
  mainTitle.textContent = track.title;
  mainArtist.textContent = track.artist;
  miniTitle.textContent = track.title;
  miniArtist.textContent = track.artist;
  miniCover.src = track.cover;
  miniCover.alt = `${track.title} cover`;
  renderCarousel();
  renderPlaylist();
  document.title = `${track.title} — Neon Music Player`;
}
function selectTrack(index, autoplay = false) {
  currentIndex = (index + tracks.length) % tracks.length;
  const track = tracks[currentIndex];
  audio.src = track.audio;
  audio.load();
  updateUI();
  seekBar.value = 0;
  currentTimeEl.textContent = '0:00';
  durationEl.textContent = '0:00';
  if (autoplay) playAudio();
}
async function playAudio() {
  try {
    await audio.play();
    playBtn.textContent = 'Ⅱ';
    playBtn.setAttribute('aria-label', 'Pause');
    playBtn.title = 'Pause';
    app.classList.remove('paused');
  } catch (error) {
    showToast('Could not play this track. Check your connection or add a local audio file.');
  }
}
function pauseAudio() {
  audio.pause();
  playBtn.textContent = '▶';
  playBtn.setAttribute('aria-label', 'Play');
  playBtn.title = 'Play';
  app.classList.add('paused');
}
function togglePlay() {
  if (audio.paused) playAudio();
  else pauseAudio();
}
function nextTrack() {
  if (isShuffle && tracks.length > 1) {
    let next = currentIndex;
    while (next === currentIndex) next = Math.floor(Math.random() * tracks.length);
    selectTrack(next, true);
  } else if (currentIndex < tracks.length - 1) selectTrack(currentIndex + 1, true);
  else if (repeatMode === 1) selectTrack(0, true);
  else pauseAudio();
}
function previousTrack() {
  if (audio.currentTime > 3) { audio.currentTime = 0; return; }
  selectTrack((currentIndex - 1 + tracks.length) % tracks.length, true);
}

document.getElementById('prevBtn').addEventListener('click', previousTrack);
document.getElementById('nextBtn').addEventListener('click', nextTrack);
document.getElementById('prevSmall').addEventListener('click', previousTrack);
document.getElementById('nextSmall').addEventListener('click', nextTrack);
playBtn.addEventListener('click', togglePlay);
document.getElementById('shuffleBtn').addEventListener('click', event => {
  isShuffle = !isShuffle;
  event.currentTarget.style.color = isShuffle ? '#ffc46a' : '';
  showToast(isShuffle ? 'Shuffle is on' : 'Shuffle is off');
});
document.getElementById('repeatBtn').addEventListener('click', event => {
  repeatMode = (repeatMode + 1) % 3;
  const labels = ['Repeat off', 'Repeat playlist', 'Repeat current track'];
  event.currentTarget.title = labels[repeatMode];
  event.currentTarget.style.color = repeatMode ? '#ffc46a' : '';
  showToast(labels[repeatMode]);
});
document.getElementById('queueBtn').addEventListener('click', () => {
  playlistPanel.hidden = !playlistPanel.hidden;
});
document.getElementById('closeQueue').addEventListener('click', () => playlistPanel.hidden = true);
document.getElementById('muteBtn').addEventListener('click', () => {
  audio.muted = !audio.muted;
  document.getElementById('muteBtn').style.color = audio.muted ? '#ffc46a' : '';
  showToast(audio.muted ? 'Muted' : 'Sound on');
});
volumeBar.addEventListener('input', () => {
  audio.volume = Number(volumeBar.value);
  if (audio.volume > 0) audio.muted = false;
});
seekBar.addEventListener('input', () => {
  if (Number.isFinite(audio.duration) && audio.duration > 0) {
    audio.currentTime = (Number(seekBar.value) / 100) * audio.duration;
  }
});
audio.addEventListener('timeupdate', () => {
  currentTimeEl.textContent = formatTime(audio.currentTime);
  if (Number.isFinite(audio.duration) && audio.duration > 0) {
    seekBar.value = (audio.currentTime / audio.duration) * 100;
  }
});
audio.addEventListener('loadedmetadata', () => durationEl.textContent = formatTime(audio.duration));
audio.addEventListener('play', () => { playBtn.textContent = 'Ⅱ'; app.classList.remove('paused'); });
audio.addEventListener('pause', () => { playBtn.textContent = '▶'; app.classList.add('paused'); });
audio.addEventListener('ended', () => {
  if (repeatMode === 2) { audio.currentTime = 0; playAudio(); }
  else if (currentIndex < tracks.length - 1 || repeatMode === 1 || isShuffle) nextTrack();
  else pauseAudio();
});

document.getElementById('uploadBtn').addEventListener('click', () => document.getElementById('fileInput').click());
document.getElementById('fileInput').addEventListener('change', event => {
  const files = Array.from(event.target.files || []).filter(file => file.type.startsWith('audio/'));
  if (!files.length) return;
  files.forEach(file => {
    const url = URL.createObjectURL(file);
    const title = file.name.replace(/\.[^.]+$/, '').replace(/[_-]+/g, ' ');
    tracks.push({
      title,
      artist: 'Your library',
      cover: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?auto=format&fit=crop&w=700&q=85',
      audio: url,
      local: true
    });
  });
  if (tracks.length === files.length + 5) {
    currentIndex = 5;
    selectTrack(currentIndex, false);
  } else {
    updateUI();
  }
  showToast(`${files.length} track${files.length === 1 ? '' : 's'} added to your playlist`);
  event.target.value = '';
});

// Start with the first demo track loaded; playback begins only when the user presses play.
audio.volume = Number(volumeBar.value);
selectTrack(0, false);
pauseAudio();
