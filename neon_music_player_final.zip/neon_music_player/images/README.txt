Place your cover images here (JPG, PNG, or WebP). In script.js, set a track's cover path like: cover: 'images/my-cover.jpg'.
