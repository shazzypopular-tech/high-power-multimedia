NEON MUSIC PLAYER — FINAL PACKAGE

Run: Extract the ZIP and open index.html in a modern browser.

Features: cinematic animations, 3D-style album carousel, play/pause, next/previous, seek, volume/mute, shuffle, repeat modes, playlist panel, Add music, and current-track download button.

Custom album covers:
1. Put your image in the images folder.
2. Open script.js and edit a track's cover property, e.g. cover: 'images/blinding-lights.jpg'.
3. The cover is rendered as an HTML <img> element and appears in the carousel and mini-player.

Custom local audio:
Use the Add music button, or edit a track's audio property to a relative path such as audio: 'music/my-song.mp3'.

Demo tracks stream from sample audio URLs and require internet. Some remote hosts may block direct downloads; local audio can be downloaded directly.
