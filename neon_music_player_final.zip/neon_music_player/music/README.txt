You can put music files here and reference them in script.js, e.g. audio: 'music/my-song.mp3'. You can also use the Add music button in the player.
